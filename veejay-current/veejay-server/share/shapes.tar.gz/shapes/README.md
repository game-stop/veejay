
All files matching '(Jon Ray)' ad 'QDSOV':

These are black and white .png files (grayscale or luma files) designed to be used for custom transitions in video editors. 
There are 2 collections, one set (8 files) designed my myself (Jonray) and the other set (12 files) by fellow Shotcut forum member QDSOV.
We made them originally for use in SHOTCUT, but they would be useable in other editors such as Kdenlive and Openshot.
To use, apply a transition (eg dissolve) between two clips, select "custom" from the dropdown list, and point to one of the .png files. The transition effect will appear. You may then select "invert wipe" for a reversed effect, and/or also control the amount of softness to apply to the transition.
All files are 1920x1080 pixels in size.

https://github.com/Jonray1/Luma-files-for-video-transitions-in-Shotcut-and-other-video-editors

All files matching '(TimFX)' 

http://www.kinodv.org
